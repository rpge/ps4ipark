# php_juhyunbot-kakao-
카카오톡에서 제공하는 옐로아이디(Yellow ID)의 자동응답 기능을 구현한 소스입니다.(php)
slim framework로 Restful 방식을 구현하였고, simple html dom을 이용해서 html 파싱을 했습니다.(노래추천 기능)
소스는 myslimproject/api/ 하위 소스를 참고하시면 됩니다. 
